def func_decorator(func):
    def warappr():
        print("---- что-то делаем перед вфзовом функции ------")
        func()
        print("----- что -то делаем посел вызва функции -----")

    return  warappr
def some_func():
    print("вызов функции some_func")
f = func_decorator(some_func)
f()