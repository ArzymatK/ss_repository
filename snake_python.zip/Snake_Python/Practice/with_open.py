# with open('my_file.txt', 'w') as file:
#     for i in range(1, 6):
#         line = f"darkside{i}\n"
#         file.write(line)

# with open('my_file.txt') as file:
#     file.seek(0)
#     for i in range(4):
#         file.readline()
#     fifth = file.readline()
#     print(fifth)

# with open('my_file.txt') as file:
#     for line in file:
#         print(line)

# with open('my_file.txt','a+') as file:
#     file.write("Welcome to Python, DarkSide")
# with open('my_file.txt') as file:
#     print(file)

# my_list = list(range(1,11))
#
# with open('my_file.txt', 'w') as file:
#     for number in my_list:
#         file.write(str(number)+'\n')

with open('my_file.txt', 'r+') as file:
    file.truncate(0)
    file.write("File is cleared")

file = open('my_file.txt')
print(file.read(10))
print(file.read(10))

#
# with open('my_file.txt', 'w') as file:
#     for i in range(1, 6):
#         line = f"{i} darkside\n"
#         file.write(line)
