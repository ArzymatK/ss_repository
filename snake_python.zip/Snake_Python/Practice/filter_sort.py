people = [
    {"name":"arzymat","age":17,"sex":"male"},
    {"name":"sanjik","age":24,"sex":"male"},
    {"name":"baimurat","age":19,"sex":"male"},
    {"name":"Megan Fox","age":33,"sex":"female"}
]
def is_adult(person: dict) -> bool:
    return person["age"] > 18
res = list(filter(is_adult, people))
print(res)