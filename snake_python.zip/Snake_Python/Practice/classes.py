class College():
    Country = "Германия"
    City = "Берлин"
    def __init__(self, office_number, teacher_data):
        self.office_number = office_number
        self.teacher_data = teacher_data

Office139 = College(139,"Shabdanaliev N.M.")
Office127 = College(127,"Ermatova.Z.E.")
Office119 = College(119,"No data about teacher")
Office120 = College(120,"Supataev E.R.")


print(f"Кабинет №{Office139.office_number}, принадлежит {Office139.teacher_data} Место нахождения: {Office139.Country},{Office139.City}")
print(f"Кабинет №{Office127.office_number}, принадлежит {Office127.teacher_data} Место нахождения: {Office127.Country},{Office127.City}")