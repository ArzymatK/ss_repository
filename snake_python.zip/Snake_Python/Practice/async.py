import asyncio
import time

async def fetch_data(url):
    print("Начало загрузки данных")
    await asyncio.sleep(3)
    print("Данные загружены")

async def main():
    tasks = [fetch_data("https://example.com") for _ in range(5)]

    await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())