from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from App.keyboards import commands, generate_task_keyboard
from App.states import CreateTask
from App.utils import load_tasks, save_task

router = Router()

tasks = load_tasks()

@router.message(Command('start'))
async def start(message: types.message):
    await message.answer('Салам алейкум!', reply_markup=commands)


@router.message(F.text == 'Добавить')
async def create_task(message: types.Message, state:FSMContext):
    await state.set_state(CreateTask.title)
    await message.answer('Введите название задачи:')

@router.message(CreateTask.title)
async def create_task_description(message: types.Message, state:FSMContext):
    await state.update_data(title=message.text)
    await state.set_state(CreateTask.description)
    await message.answer('Введите описание задачи')


@router.message(CreateTask.description)
async def create_task_deadline(message: types.Message, state:FSMContext):
    await state.update_data(description=message.text)
    await state.set_state(CreateTask.deadline)
    await message.answer('Введите срок выполнения:')


@router.message(CreateTask.deadline)
async def create_task_finally(message: types.Message, state:FSMContext):
    user_id = message.from_user.id
    task_data = await state.get_data()
    task_data.update({'deadline': message.text, 'status': False})
    tasks[str(user_id)] = tasks.get(str(user_id), []) + [task_data]
    save_task(tasks)
    await state.clear()
    await message.answer('Задача добавлена!')


@router.message(F.text == 'Список')
async def list_task(message: types.Message):
    user_id = message.from_user.id
    keyboard = generate_task_keyboard(user_id)
    if keyboard.inline_keyboard:
        await message.answer('Ваш список задач:', reply_markup=keyboard)
    else:
        await message.answer('У вас пока нет задач.')


@router.callback_query(F.data.startswith('task_'))
async def retrieve_task(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    task_index = int(callback.data.split('_')[1])
    tasks = load_tasks()
    user_tasks = tasks.get(str(user_id), [])
    if task_index < len(user_tasks):
        task = user_tasks[task_index]
        task_details = (
            f"Название: {task.get('title', 'Без названия')}\n"
            f"Описание: {task.get('description', 'Без описания')}\n"
            f"Срок выполнения: {task.get('deadline', 'Не указан')}\n"
            f"Статус: {'Выполнена' if task.get('is_completed', False) else 'Не выполнена'}"
        )
        await callback.message.answer(task_details)
        await callback.answer()
    else:
        await callback.answer("Задача не найдена.", show_alert=True)


@router.message(F.text == "Удалить")
async def remove_task(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    user_tasks = tasks.get(str(user_id), [])
    await message.answer("Выберите задачу, которую хотите удалить:", reply_markup=generate_task_keyboard(user_id))

@router.callback_query(F.data.startswith('remove_task_'))
async def remove_task_callback(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    task_index = int(callback.data.split('_')[1])
    user_tasks = tasks.get(str(user_id), [])
    if task_index < len(user_tasks):
        removed_task = user_tasks.pop(task_index)
        tasks[str(user_id)] = user_tasks
        save_task(tasks)
        await callback.answer(f"Задача '{removed_task.get('title', 'Без названия')}' удалена.")
    else:
        await callback.answer("Задача не найдена.")