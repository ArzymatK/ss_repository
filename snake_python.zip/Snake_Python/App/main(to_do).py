import logging, asyncio, sys
from aiogram import Bot, Dispatcher
from App.handler import router

TOKEN = "7073498005:AAGxQawjEktD_ec3pqY0WtixApRNr6bekPY"

async def main():
    bot = Bot(token=TOKEN)
    dp = Dispatcher()
    dp.include_router(router)
    await dp.start_polling(bot)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('Bot stopped')
    