from aiogram.utils.keyboard import ReplyKeyboardMarkup, InlineKeyboardBuilder
from aiogram.types import KeyboardButton, InlineKeyboardButton
from App.utils import load_tasks

commands = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text='Добавить')],
        [KeyboardButton(text='Список')],
        [KeyboardButton(text='Обновить')],
        [KeyboardButton(text='Удалить')]
    ],
    resize_keyboard=True
)

def generate_task_keyboard(user_id):
    tasks = load_tasks()
    user_tasks = tasks.get(str(user_id), [])
    keyboard = InlineKeyboardBuilder()

    for index, task in enumerate(user_tasks):
        task_title = task.get('title', 'No title')
        keyboard.add(InlineKeyboardButton(text=task_title, callback_data=f'task_{index}'))
    return keyboard.adjust(1).as_markup()