import telebot
import dark

bot = telebot.TeleBot(dark.TOKEN)

@bot.message_handler(content_types=['text'])
def mess(message):
    bot.send_message(message.chat.id,message.text)

bot.infinity_polling()

