from telebot import TeleBot

TOKEN = "6877403068:AAFodUB4rCEtAVJ57_ZkvdjxQFUFCZWEIzw"

bot = TeleBot(TOKEN)


@bot.message_handler(commands=["start", "help"])
def send_welcome(message):
    print(message)
    bot.reply_to(message, text="Welcome to Karypbaevv's bot")


bot.infinity_polling()
