"""Polymorphism"""
class Animal:
    def voice(self):
        raise NotImplementedError("Этот метод должен быть переопределен в подклассе")

class Dog(Animal):

    def voice(self):
        print("Gaff-Gaff")

class Cat(Animal):

    def voice(self):
        print("Meow-Meow")

class Donkey(Animal):

    def voice(self):
        print("I am Kasym - I am Kasym")

cat1, cat2 = Cat(), Cat()
dog1, dog2 = Dog(), Dog()
donkey1, donkey2 = Donkey(), Donkey()

animals = [cat1, cat2, dog1, dog2, donkey1, donkey2]

for animal in animals:
    animal.voice()