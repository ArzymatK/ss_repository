"""Наследование"""
class Vehicles():
    def __init__(self, name, model, **kwargs):
        self.name = name
        self.model = model
        if 'passanger' in kwargs:
            self.passanger = kwargs['passanger']
        else:
            self.passanger = 1

class Car(Vehicles):
    def __init__(self, name, model, **kwargs):
        super().__init__(name, model, **kwargs)
        self.model = model
        if 'fwd' in kwargs:
            self.fwd = kwargs['fwd']
        else:
            self.fwd = False

audi = Car('Audi', 'A4 3.0')
print(audi.__dict__)
bmw = Car("BMW","m5",)
print(bmw.__dict__)
mercedes =Car("Mercedes-Benz", "212")
print(mercedes.__dict__)
