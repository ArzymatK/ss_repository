class Kattle:
    def turn_on(self):
        print("Нажали кнопку")
        self.__boil()
        self.__check_temperature()
        self.__beep()
        self.__turn_off()

    def __boil(self):
        print("Разогравение воды...")
    def __check_temperature(self):
        print("Проверяем температуру воды...")
    def __beep(self):
        print("Подаем звуковой сигнал")
    def __turn_off(self):
        print("Автоматическое выключение чайника")

my_kettle = Kattle()
my_kettle.turn_on()