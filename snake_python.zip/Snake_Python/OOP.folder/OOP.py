"""Процедурный подход"""
width = 5
height = 10
def CalcArea(width, height):
    return width * height

print(CalcArea(width,height))

"""Объектно-ориентированный подход"""
class Rectangle(width, height):
    