open_weather_token = "60b7f3b48b1a4994bb0bc06f35dc608e"
tg_bot_token = "7038870614:AAFSQuLecQH190p9Y4hFh62aWRX_74RoYEk"