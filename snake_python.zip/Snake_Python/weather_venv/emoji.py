smile = "\U0001F600"
print(smile)