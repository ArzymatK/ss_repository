import requests
import datetime
from config import tg_bot_token, open_weather_token
from aiogram import Bot, types
from aiogram.dispatcher import dispatcher
from aiogram.utils import executor


bot = Bot(token=tg_bot_token)
dp = dispatcher(bot)


@dp.message_handler(commands=["start"])
async def start_command(message: types.Message):
    await message.reply("Привет! Напиши мне название города и я пришлю тебе состояние её погоды")


if __name__ == "__main__":
    executor.start_polling(dp)
