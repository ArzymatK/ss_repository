import requests
from telebot import TeleBot
import random
from bs4 import BeautifulSoup as b

URL = "https://www.factretriever.com/interesting-facts"
TOKEN = "7049952294:AAHd7HYwRPNs0WOQvP8oiKTxpG7KPj_kjBA"
def parser(url):
    r = requests.get(URL)
    soup = b(r.text, 'html.parser')
    facts = soup.find_all('div',class_='text')
    return [f.text for f in facts]

list_of_facts = parser(URL)
random.shuffle(list_of_facts)

bot = telebot.TeleBot(TOKEN)
@bot.message_handler(commands=['start'])

def introduce(message):
    bot.send_message(message.chat.id,"Hello stranger! Are you ready to know smth new?")

@bot.message_handler(content_types=['text'])
def facts(message):
    if message.text.lower() in '123456789':
        bot.send_message(message.chat.id, list_of_facts[0])
        del list_of_facts[0]
    else:
        bot.send_message(message.chat.id, "Enter any number from 1 to 10: ")
try:
    bot.polling()
except IndexError:
    print("Bot is stopped. Cause of IndexError")