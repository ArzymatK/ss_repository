from bs4 import BeautifulSoup

with open("index.html", encoding="utf-8") as file:
    src = file.read()
#print(src)

soup = BeautifulSoup(src, "lxml")

# title = soup.title
# print(title)
# print(title.text)

# page_h1 = soup.find("h1")
# print(page_h1)

# page_all_h1 = soup.find_all("h1")
# print(page_all_h1)
#
# for item in page_all_h1:
#     print(item.text)

# user_name = soup.find("div", class_="user__name")
# print(user_name.text.strip())

# user_birth_date = soup.find("div", class_="user__birth__date")
# print(user_birth_date.text)

# user_city = soup.find("div", class_="user__city")
# print(user_city.text)#Город: Los Angeles

# user_city = soup.find(class_="user__city").find("span").text
# print(user_city)#Город

# user_name = soup.find("div", {"class": "user__name", "id":"aaa"}).find("span").text
# print(user_name)

# find_all_spans_in_user_info=soup.find(class_="user__info").find_all("span")
# print(find_all_spans_in_user_info)
#
# for item in find_all_spans_in_user_info:
#     print(item.text)

#print(find_all_spans_in_user_info[0].text)
#Mr. Purple

#print(find_all_spans_in_user_info[1].text)
#Mr. Andreson

# social_links = soup.find(class_="social__networks").find("ul").find_all("a")
# print(social_links)

# all_a = soup.find_all("a")
# print(all_a)

# for item in all_a:
#     item_text = item.text
#     item_url = item.get("href")
#     print(f"{item_text}:{item_url}")

