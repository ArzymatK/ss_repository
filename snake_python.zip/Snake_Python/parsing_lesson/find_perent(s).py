from bs4 import BeautifulSoup

with open("index.html", encoding="utf-8") as file:
    src = file.read()

post_div = soup.find(class_="post__text").find_parent()
print(post_div)