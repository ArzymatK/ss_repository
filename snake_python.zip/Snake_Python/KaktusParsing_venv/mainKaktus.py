import json, asyncio, logging, sys, os
from aiogram import Bot, types, Dispatcher, Router, F
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from ParsingKak import today, parse_news

router = Router()
TOKEN = '7080407562:AAGwVrE58rwUs5P82PaCP3eO7PFrwpEHPLw'

async def get_keyboard():
    keyboard = InlineKeyboardBuilder()
    with open(f'news_{today}.json', 'r') as file:
        for number, news in enumerate(json.load(file)):
            keyboard.add(
                types.InlineKeyboardButton(
                text=news['title'],
                    callback_data=str(number)
                )
            )
    return keyboard.adjust(1).as_markup()

@router.message(Command('start'))
async def start(message: types.Message):
    # await message.answer('Hello', reply_markup= await get_keyboard())
    if not os.path.exists(f'news_{today}.json'):
        await parse_news()
    await message.answer(f'Привет, {message.from_user.first_name}! Новости на сегодня:', reply_markup=await get_keyboard())


@router.callback_query(F.data)
async def send_news_detail(callback: types.CallbackQuery):
    with open(f'news_{today}.json', 'r') as file:
        news = json.load(file)[int(callback.data)]
        text = f'{news['title']}\n{news['description']}\n{news['news_link']}'
        await callback.message.answer(text=text)


async def main():
    bot = Bot(TOKEN)
    dp = Dispatcher()
    dp.include_router(router)
    await dp.start_polling(bot)

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('Bot stopped')